#Load Packages
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
from keras.layers import Conv2D, MaxPooling2D, BatchNormalization
from keras.layers import Activation, Dropout, Flatten, Dense
from dataloader import LoadGPSData

# Seed value (can actually be different for each attribution step)
seed_value = 5

# 1. Set `PYTHONHASHSEED` environment variable at a fixed value
import os
os.environ['PYTHONHASHSEED']=str(seed_value)

# 2. Set `python` built-in pseudo-random generator at a fixed value
import random
random.seed(seed_value)

# 3. Set `numpy` pseudo-random generator at a fixed value
import numpy as np
np.random.seed(seed_value)

# 4. Set `tensorflow` pseudo-random generator at a fixed value
import tensorflow as tf
tf.random.set_seed(seed_value) # tensorflow 2.x
# tf.set_random_seed(seed_value) # tensorflow 1.x

sequence_length = 1
epochs = 100
batch_size = 32

gps_data_loader = LoadGPSData(sequence_length = sequence_length)

X, y = gps_data_loader.get_data("Dataset")



model = Sequential()
model.add(LSTM(8,input_shape=(sequence_length,3),return_sequences=False)) #True = many to many
model.add(Dense(10, activation='linear'))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='bce',optimizer ='adam',metrics=['accuracy'])
print(model.summary())
#%%
#training loss and Validation Loss Plots
history = model.fit(X,y,epochs=epochs,batch_size=batch_size,validation_split=0.3);
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(1, len(loss) + 1)
plt.plot(epochs, loss, 'y', label='Training loss')
plt.plot(epochs, val_loss, 'r', label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()

#%%
#Training Accuracy and Validation Accuracy
accuracy = history.history['accuracy']
val_accuracy = history.history['val_accuracy']
plt.plot(epochs, accuracy, 'y', label='Training acc')
plt.plot(epochs, val_accuracy, 'r', label='Validation acc')
plt.title('Training and Validation accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()
scores = model.evaluate(X,y,batch_size=batch_size)
print('Accurracy: {}'.format(scores[1]*100.0))
print(len(y), len(X))


#%%

X = gps_data_loader.get_test_data("E:\Masters Semester 3\Machine Learning\Project\LSTM_Model\LSTM_Model\Dataset\data test")
#print("the value is: ", model.predict(X))
prediction = model.predict(X)
print("prediction shape:", prediction.shape)
#%%

print(len(y), len(X))

#%%
mythreshold = 0.5
y_pred = (model.predict(X)>= mythreshold).astype(int)
cm = confusion_matrix(y, y_pred)
print(cm)

#%%
from sklearn.metrics import roc_curve
y_preds = model.predict(X).ravel()
fpr, tpr, thresholds = roc_curve(y, y_preds)
plt.figure(1)
plt.plot([0, 1], [0, 1], 'y--')
plt.plot(fpr, tpr, marker='.')
plt.xlabel('False positive rate')
plt.ylabel('True positive rate')
plt.title('ROC curve')
plt.show()

#%%
import pandas as pd
i = np.arange(len(tpr))
roc = pd.DataFrame({'tf' : pd.Series(tpr-(1-fpr), index=i), 'thresholds' : pd.Series(thresholds, index=i)})
ideal_roc_thresh = roc.iloc[(roc.tf-0).abs().argsort()[:1]]  #Locate the point where the value is close to 0
print("Ideal threshold is: ", ideal_roc_thresh['thresholds'])

#%%
from sklearn.metrics import auc
auc_value = auc(fpr, tpr)
print("Area under curve, AUC = ", auc_value)

#%%
print("X: ",len(X))
print(len(y))
print(len(y_pred))

#cm=confusion_matrix(y, y_pred)
#print(cm)
''''''


